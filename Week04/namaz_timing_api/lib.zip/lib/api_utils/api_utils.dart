class ApiUtils {
  static String prayerUrl = "http://api.aladhan.com/v1/calendarByCity/2017/4?city=Abbottabad&country=Pakistan&method=2";

  // static String productUrl = "${url}products";



}
